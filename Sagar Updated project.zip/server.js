// set up ========================
    var express  = require('express');
    var app      = express();                               
                   
    var morgan = require('morgan');             
    var bodyParser = require('body-parser');    
    var methodOverride = require('method-override'); 

    var MongoClient = require('mongodb').MongoClient
        , assert = require('assert');
    var url = 'mongodb://localhost:27017/sagarTaskDB';
    var ObjectID = require('mongodb').ObjectID;
    // configuration =================

    //mongoose.connect('mongodb://node:nodeuser@mongo.onmodulus.net:27017/uwO3mypu');     // connect to mongoDB database on modulus.io

    app.use(express.static(__dirname + '/public'));                 
    app.use(morgan('dev'));                                         
    app.use(bodyParser.urlencoded({'extended':'true'}));            
    app.use(bodyParser.json());                                     
    app.use(bodyParser.json({ type: 'application/vnd.api+json' })); 
    app.use(methodOverride());

    // listen (start app with node server.js) ======================================
    app.listen(7117);
    console.log("App listening on port 7117");
    
    app.post('/json/initializeDB', function(req, res) {
        console.log("/json/initializeDB called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            db.collection("users_ULP").findOne({EmailID: 'sagar@my.com'}, function(err, doc){
                console.log(doc);
                if(doc == null){
                    db.collection("users_ULP").insertOne({EmailID: 'sagar@my.com', Password: 'admin'}, function(err, suc){
                        console.log(err);
                        console.log(suc);
                        db.close();
                    });
                }
            });
            
        });
        MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            
            db.collection("ControlFile_TEX").findOne({IsBatchEmail: false}, function(err, doc){
                console.log(doc);
                if(doc == null){
                    db.collection("ControlFile_TEX").insertOne({IsBatchEmail: false}, function(err, suc){
                        console.log(err);
                        console.log(suc);
                        db.close();
                    });
                }
            });
            res.status(200);
            res.json({initializeDBSuccess: true});
         });
        
    });
    app.get('/json/news/newsList', function(req, res) {
        console.log("/json/news/newsList called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            
            db.collection("News_WES").find({}).toArray(function(err, docs){
                if(err){
                    res.status(200);
                    res.json([]);
                    return;
                }
                console.log(docs);
                res.status(200);
                res.json(docs);
            });
            db.close();
         });
    });
    
    app.post('/json/adminLogin', function(req, res) {
        console.log("/json/adminLogin called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            console.log(req.body);
            db.collection("users_ULP").find(req.body).toArray(function(err, docs){
                console.log(docs.length);
                
                
                if(docs.length >= 1){
                    res.status(200);
                    res.json({loginSuccess: true});
                }  
                else{
                    res.status(404);
                     res.json({loginSuccess: false}); 
                }
            });
         });
        
    });
    app.get('/json/GetNewsByID', function(req, res) {
        console.log("/json/news/newsList called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            console.log(req.query);
            
            var objid = new ObjectID(req.query._id);
            db.collection("News_WES").findOne({_id: objid}, function(err, doc){
                console.log(doc);
                res.status(200);
                res.json(doc);
            });
         });
    });
    app.post('/json/newsOperation', function(req, res) {
        console.log("/json/newsOperation called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            console.log(req.body);
            db.collection("News_WES").insertOne(req.body, function(err, suc){
                    console.log("No of News Inserted : "+suc.insertedCount);
            });
            db.close();
            res.status(200).json(req.body);
        });
        
    });
    app.put('/json/newsOperation', function(req, res) {
        console.log("/json/newsOperation called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            console.log(req.body);
            var objid = new ObjectID(req.body._id);
            db.collection("News_WES").updateOne({_id: objid }, {$set: {NewsBody: req.body.NewsBody}}, function(err, suc){
                    console.log("No of News Inserted : "+suc.insertedCount);
            });
            db.close();
            res.status(200).json(req.body);
        });
        
    });
    app.delete('/json/newsOperation', function(req, res) {
        console.log("/json/newsOperation called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            console.log(req.query);
            var objid = new ObjectID(req.query._id);
            db.collection("News_WES").deleteOne({_id: objid }, function(err, suc){
                    console.log("No of News Inserted : "+suc.deletedCount);
            });
            db.close();
            res.status(200).json(req.body);
        });
        
    });
    app.get('/json/quote/quoteList', function(req, res) {
        console.log("/json/quote/quoteList called");
         MongoClient.connect(url, function(err, db) {
            console.log("Connected successfully to server");
            db.collection("Quote_YHN").find({}).toArray(function(err, docs){
                console.log(docs);
                res.status(200);
                res.json(docs);
            });
         });
        
    });
    app.get('/json/quote/quoteSummary', function(req, res) {
        console.log("/json/quote/quoteSummary called");
        MongoClient.connect(url, function(err, db) {
                console.log("Connected successfully to server");
                
                db.collection("Quote_YHN").aggregate([
                    {$match: {}}
                    , {$group:
                        {
                            _id: '$status', 
                            statusCount: {$sum: 1} ,
                            averageAnnualPremium: { $avg: "$annualPremium" },
                        }
                    }
                    ]).toArray(function(err, docs) {
                        console.log(docs[0]._id+" "+docs[0].statusCount+" "+docs[0].averageAnnualPremium);
                        console.log(docs[1]._id+" "+docs[1].statusCount+" "+docs[1].averageAnnualPremium)
                        db.close();
                        res.status(200);
                        res.send({
                            success: docs[0].statusCount,
                            failure: docs[1].statusCount,
                            averageAnnualPremium: docs[0].averageAnnualPremium
                        })
                    });
            });
    });
    app.post('/sendEmail', function(req, res) {
        console.log("/sendEmail");
        
        var quote = req.body;
        quote.status = 'None';
        console.log("quote first .....");
        console.log(quote);
        quote.quoteError = {};
        callAmazonREST(quote, res);
        //res.status(200).send('Success');
       
    });
    app.get('*', function(req, res) {
        console.log("* Called");
        var isAjaxRequest = req.xhr;
        console.log(isAjaxRequest);
        if(!isAjaxRequest)
            res.sendFile('public/index.html' , { root : __dirname});
    });
    

    var callAmazonREST = function(quote, expressResponse){
        var headers = {
            'Content-Type': 'application/json',
            'x-api-key': 'L0Q3GvXCwB9jVSmvaJbw5augw4xHCvMy4Egqim2p'
        };
        var dataString = {
            owner_name: quote.ownerName,
            model: quote.jetModel,
            seat_capacity: parseInt(quote.jetSeatCapacity),
            manufactured_date: new Date(quote.manufacturingDate),
            purchase_price: parseFloat(quote.purchasePrice),
            broker_email: quote.brokerEmail
        }
        console.log("dataString");
        console.log(dataString);
        var https = require('https');
        var options = {
            host: 'j950rrlta9.execute-api.us-east-2.amazonaws.com',
            path: '/v1/ArgoChallenge',
            method: "POST",
            headers: headers
        };

        var req = https.request(options, function(res) {
            res.setEncoding('utf-8');
            var responseString = '';
            res.on('data', function(data) {
                console.log("data.........");
                responseString += data;
            });
            
            res.on('end', function() {
                console.log("end.........");
                var responseObject = JSON.parse(responseString);
                console.log(responseObject);
                if("ok" in responseObject && responseObject.ok === true){
                    quote.annualPremium = responseObject.data.annual_premium;
                    quote.status = "Success";
                }else{
                    quote.annualPremium = 0;
                    quote.status = "Failue";
                }
                console.log("quote second...............");
                console.log(quote);
                sendQuoteEmail(quote, expressResponse);
                console.log(responseObject);
            });
        });

        req.write(JSON.stringify(dataString));
        req.end();
        
    };

    var sendQuoteEmail = function(quote, expressResponse){
        console.log("sendQuoteEmail Called");
        const nodemailer = require('nodemailer');
        let transporter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 465,
            secure: true, // secure:true for port 465, secure:false for port 587
            auth: {
                user: 'gym.prathap@gmail.com',
                pass: 'bkzlkcumbdmobfvu'
            }
        });

        let mailOptions = {
            from: '"Sagar" <gym.prathap@gmail.com>', // sender address
            to: 'kannan@wisensoft.com, tsagar7477@gmail.com', // list of receivers
            subject: 'Task from Sagar ✔', // Subject line
            text: 'Sagar Tasks', // plain text body
            html: '<b>Hi</b><br/><br/><div>Private Jet Liability Insurance Quote Details are </div><br/><br/><table style="border-collapse: collapse;font-size:Arial;" cellpadding="0" cellspacing="0"><tr><td style="padding:10px;border:1px solid black"><b>Owner Name</b></td><td style="padding:10px;border:1px solid black;">'+quote.ownerName+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Jet Model</b></td><td style="padding:10px;border:1px solid black;">'+quote.jetModel+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Jet Seat Capacity</b></td><td style="padding:10px;border:1px solid black;text-align:right;">'+quote.jetSeatCapacity+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Manufacturing Date</b></td><td style="padding:10px;border:1px solid black;text-align:right;">'+quote.manufacturingDate+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Purchase Price</b></td><td style="padding:10px;border:1px solid black;text-align:right;">'+parseFloat(quote.purchasePrice).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Broker Email</b></td><td style="padding:10px;border:1px solid black;">'+quote.brokerEmail+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Annual Premium</b></td><td style="padding:10px;border:1px solid black;text-align:right;">'+parseFloat(quote.annualPremium).toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")+'</td></tr><tr><td style="padding:10px;border:1px solid black;"><b>Status</b></td><td style="padding:10px;border:1px solid black;font-size:18px;'+(quote.status === 'Success' ?'color:green' : 'color:red')+'"><b>'+quote.status+'</b></td></tr></table><br/><br/><div>With Kind Regards</div><br/><br/><div><b>Sagar</b></div>' // html body
        };

        

       console.log("sendmail...................");
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                console.log("sendmail error...................");
                quote.messageId = 'Error';
                quote.response = 'Email Sent Error Response';
                insertQuote(quote, expressResponse);
                return console.log(error);
            }
            console.log('Message123 %s sent: %s', info.messageId, info.response);
            quote.messageId = info.messageId;
            quote.response = info.response;
            insertQuote(quote, expressResponse);
        }); 
    }

    var insertQuote = function(quote, expressResponse){
        console.log("insertQuote Called");
       // console.log(quote);
        
        MongoClient.connect(url, function(err, db) {
                console.log("Connected successfully to server");
                db.collection("Quote_YHN").insertOne(quote, function(err, suc){
                    console.log("No of Quotes Inserted : "+suc.insertedCount);
                });
                db.close();
                if(quote.status === 'Success')
                    expressResponse.status(200).json(quote);
                else
                    expressResponse.status(500).json(quote);
            });
    };