﻿console.log("Tasks.jsinside")
var taskModule = angular.module("taskApp", ['ngRoute', 'ngSanitize','ngMessages', 'ng.ckeditor']);
taskModule.config(['$locationProvider',
function ($locationProvider) {
    console.log("HTML5 Mode Started");
    $locationProvider.html5Mode(true);
}
]);

taskModule.config(['$qProvider', function ($qProvider) {
    $qProvider.errorOnUnhandledRejections(false);
}]);

taskModule.config(['$routeProvider', '$httpProvider',
function ($routeProvider, $httpProvider) {
    console.log("$routeProvider")
    $httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
    $routeProvider.when('/', {
        redirectTo: '/Home'
    })
     .when('/Home', {
         templateUrl: 'homeid',
         controller: 'HomeController'
     })
    .when('/Home/Task1', {
        templateUrl: 'task1id',
        controller: 'Task1Controller'
    })
    .when('/Home/Task2', {
        templateUrl: 'task2id',
        controller: 'Task2Controller'
    })
    .when('/News/AdminLogin', {
            templateUrl: 'adminloginid',
            controller: 'NewsAdminLoginController'
    })
    .when('/News/NewsListing', {
        templateUrl: 'newslistingid',
            controller: 'NewsListingController'
    })
    .when('/News/NewsOperation/:dmloperation/:objectid?', {
            templateUrl: 'newsoperationid',
            controller: 'NewsOperationController'
        })
    .when('/Home/Task3', {
        templateUrl: 'task3id',
        controller: 'Task3Controller'
    })
   .when('/Quote/QuoteOperation/:dmloperation/:uniqueid?', {
       templateUrl: 'quoteoperationid',
       controller: 'QuoteOperationController'
    })
    .when('/Home/Task4', {
        templateUrl: 'task4id',
        controller: 'Task4Controller'
    })
    .when('/Home/Task5', {
        templateUrl: 'task5id',
        controller: 'Task5Controller'
    })
}]);
taskModule.controller('HomeController', function ($scope, $route, $routeParams, $http) {
    console.log("HomeController");
});
taskModule.controller('Task1Controller', function ($scope, $route, $routeParams, $http) {
    console.log("Task1Controller");
});
taskModule.controller('Task2Controller', function ($scope, $route, $routeParams, $http) {
    console.log("Task2Controller");
    $http({
        method : "GET",
        url : "/json/news/newsList"
    }).then(function mySuccess(response) {
        console.log("/json/news/newsList success");
        $scope.newsList = response.data;
    }, function myError(response) {
        console.log("/json/news/newsList ERROR");;
    });
});
taskModule.controller('NewsAdminLoginController', function ($scope, $route, $routeParams, $http, $location) {
    console.log("NewsAdminLoginController");
    $scope.loginClicked = function(evt){
        if ($scope.adminLoginForm.$invalid) {
            angular.forEach($scope.adminLoginForm.$error, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                });
            });
            return false;
        }
        $http({
            method : "POST",
            data: $scope.record,
            url : "/json/adminLogin"
        }).then(function mySuccess(response) {
            console.log("/json/adminLogin success");
            $location.path('/News/NewsListing');
            $scope.isError = false;
        }, function myError(response) {
            console.log("/json/adminLogin ERROR");;
            $scope.loginResult = response.data;
            $scope.isError = true;
        });
    };
});
taskModule.controller('NewsListingController', function ($scope, $route, $routeParams, $http) {
    console.log("NewsListingController");
    $http({
        method : "GET",
        url : "/json/news/newsList"
    }).then(function mySuccess(response) {
        console.log("/json/news/newsList success");
        $scope.newsList = response.data;
    }, function myError(response) {
        console.log("/json/news/newsList ERROR");;
    });
    
});
taskModule.controller('NewsOperationController', function ($scope, $route, $routeParams, $location, $http) {
    console.log("NewsOperationController");
    $scope.dmloperation = $routeParams.dmloperation;
    $scope._id = $routeParams.objectid;
    $scope.isDelete = false;
    if($scope.dmloperation !== 'Create'){
        $http({
            method : "GET",
            url : "/json/GetNewsByID?_id="+$scope._id
        }).then(function mySuccess(response) {
            console.log("/json/quote/quoteList success");
            $scope.record = response.data;
            console.log(response.data);
            console.log(CKEDITOR.instances);
            if($scope.dmloperation !== 'Delete' && CKEDITOR.instances.TNewsBody === undefined){
                CKEDITOR.instances.TNewsBody.setData($scope.record.NewsBody);
                $('#TNewsBody').val($scope.record.NewsBody);
                CKEDITOR.instances.TNewsBody.updateElement();
            }
            
        }, function myError(response) {
            console.log("/json/quote/quoteList ERROR");;
        });
    };
    if($scope.dmloperation === 'Delete'){
        $scope.isDelete = true;
        console.log($('#cke_TNewsBody').length);
        CKEDITOR.on('instanceReady', function() { $('#cke_TNewsBody').hide(); });
        
    }
    $scope.newsSaveClicked = function (evt) {
        
        console.log("newsSaveClicked");
        $scope.isNewsBodyError = false;
        
        if ($scope.newsOperationForm.$invalid) {
            angular.forEach($scope.newsOperationForm.$error, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                });
            });
            return false;
        }
        var newsBody = CKEDITOR.instances.TNewsBody.getData();
        if($scope.dmloperation !== 'Delete'){
            
            if(newsBody.length <= 20){
                $scope.isNewsBodyError = true;
                return;
            }
        }
            console.log(newsBody);
            $scope.record.NewsBody = newsBody;

        
        $scope.record.Timestamp = new Date();
        console.log($scope.record);
        switch($scope.dmloperation){
            case 'Create':{
                console.log('Create');
                $scope.operationName = "Create News"
                $http({
                    method : "POST",
                    data: $scope.record,
                    url : "/json/newsOperation"
                }).then(function mySuccess(response) {
                    console.log("/json/newsOperation success");
                    $location.path('/News/NewsListing');
                }, function myError(response) {
                    console.log("/json/newsOperation ERROR");;
                    $scope.loginResult = response.data;
                });
                break;
            }
            case 'Edit':{
                $scope.operationName = "Update News"
                $http({
                    method : "PUT",
                    data: $scope.record,
                    url : "/json/newsOperation"
                }).then(function mySuccess(response) {
                    console.log("/json/newsOperation success");
                    $location.path('/News/NewsListing');
                }, function myError(response) {
                    console.log("/json/newsOperation ERROR");;
                    $scope.loginResult = response.data;
                });
                break;
            }
            case 'Delete':{
                $scope.operationName = "Delete News"
                $http({
                    method : "DELETE",
                    
                    url : "/json/newsOperation?_id="+$scope._id
                }).then(function mySuccess(response) {
                    console.log("/json/newsOperation success");
                    $location.path('/News/NewsListing');
                }, function myError(response) {
                    console.log("/json/newsOperation ERROR");;
                    $scope.loginResult = response.data;
                });
                break;
            }
            default:
            {
                break;
            }
        }
        

    }
    $scope.newsResetClicked = function (evt) {
        
    }
});
taskModule.controller('Task3Controller', function ($scope, $route, $routeParams, $http) {
    console.log("Task3Controller");
    $http({
        method : "GET",
        url : "/json/quote/quoteList"
    }).then(function mySuccess(response) {
        console.log("/json/quote/quoteList success");
        $scope.quoteList = response.data;
    }, function myError(response) {
        console.log("/json/quote/quoteList ERROR");;
    });
});
taskModule.controller('QuoteOperationController', function ($scope, $route, $routeParams, $location, $http) {
    console.log("QuoteOperationController");
    console.log($routeParams.dmloperation);
    $scope.dmloperation = $routeParams.dmloperation;
    $scope.unqiueid = $routeParams.unqiueid;
    switch($scope.dmloperation){
        case 'Create':{
            console.log('Create');
            $scope.operationName = "Create News"
            break;
        }
        case 'Edit':{
            $scope.operationName = "Update News"
            break;
        }
        case 'Delete':{
            $scope.operationName = "Delete News"
            break;
        }
        default:
        {
            break;
        }
    }
    $scope.quoteSaveClicked = function (event) {
        if ($scope.quoteForm.$invalid) {
            angular.forEach($scope.quoteForm.$error, function (field) {
                angular.forEach(field, function (errorField) {
                    errorField.$setTouched();
                });
            });
            return false;
        }
        $scope.quoteForm.$setPristine();
        $scope.quoteForm.$setUntouched();
        console.log($('#quoteForm'));
        $('#quoteForm')[0].reset();
        $('#loadingModel').modal({
            backdrop: false,
            keyboard: false,
            focus: true
        }).show();
        console.log($scope.record);
        $http({
                method : "POST",
                url : "/sendEmail",
                data: $scope.record,
                headers: {
                    'Content-Type': 'application/json'
                }
            }).then(function mySuccess(response) {
                console.log("/senEmail success");
                console.log(response);
                $scope.serverQuote = response.data;
                $('#loadingModel').hide();
                $('#quoteresult').modal({
                    focus: true
                }).show();
                console.log($('#loadingModel'));
            }, function myError(response) {
                console.log("/sendEmail ERROR");
                console.log(response);
                $scope.serverQuote = response.data;
                 $('#loadingModel').hide();
                console.log($('#loadingModel'));
                $('#quoteresult').modal({
                    focus: true
                }).show();
            });
           
        
    }
    $scope.quoteCancelClicked = function (event) {
        $location.path('/Home/Task3');
    }
});
taskModule.controller('Task4Controller', function ($scope, $route, $routeParams, $http) {
    console.log("Task4Controller");
    $scope.show = false;
    $scope.isEnable = true;
    $scope.btnText = 'Enable Send Quote in Batch';
    $scope.enableDisableClicked = function (evt) {
        $scope.show = true;
        
        if ($scope.isEnable) {
            $scope.msg = 'Send Quote in Batch Successully Enabled';
            $scope.btnText = 'Dsiable Send Quote in Batch';
        }
        else {
            $scope.msg = 'Send Quote in Batch Successully Disabled';
            $scope.btnText = 'Enable Send Quote in Batch';
        }
        $scope.isEnable = !$scope.isEnable;
    };
});
taskModule.controller('Task5Controller', function ($scope, $route, $routeParams, $http) {
    console.log("Task5Controller");
    $http({
        method : "GET",
        url : "/json/quote/quoteSummary"
    }).then(function mySuccess(response) {
        console.log("/json/quote/quoteList success");
        $scope.quoteSummary = response.data;
    }, function myError(response) {
        console.log("/json/quote/quoteList ERROR");;
    });
});
